#!/bin/bash
NGINX_SERVERS_EFS_PATH=/mnt/efs/fs1/config/
NGINX_SERVERS_LOCAL_PATH=/usr/local/nginx/config/
CONF_HASH_FILE_CURRENT=/mnt/efs/fs1/config/config_date_modified.txt
CONF_HASH_FILE=/tmp/current_conf.hash
LOG_FILE=/usr/local/nginx/logs/servers/reload.log
OUTPUT_FILE=/usr/local/nginx/logs/servers/output-reload.log
NGINX_BIN=/usr/local/nginx/sbin/nginx
INSTANCE_ID=$(ec2metadata --instance-id | cut -d " " -f 2)

main () {

    # Sync certificates (local path with efs)
    sync_certificates_with_efs

    # Calculate current conf files hash
    current_conf_hash=$([ -f $CONF_HASH_FILE_CURRENT ] && cat $CONF_HASH_FILE_CURRENT);

    # Compare with the previous hash value
    previous_conf_hash=$([ -f $CONF_HASH_FILE ] && cat $CONF_HASH_FILE);
    if [ "$previous_conf_hash" != "$current_conf_hash" ]; then
        reload_nginx
    fi

    notice_to_datadog "mshops.nginx.config_cron.ok:1|c|#shell-ec2"
}

sync_certificates_with_efs(){
    log_info "Start sync certificates";
    rclone sync --create-empty-src-dirs "$NGINX_SERVERS_EFS_PATH" "$NGINX_SERVERS_LOCAL_PATH"
    log_info "Finish sync certificates";
}

reload_nginx () {
    log_info 'Reloading nginx';

    datestring=$(date +'%Y-%m-%d %H:%M:%S')
    echo "$datestring $INSTANCE_ID" >> $OUTPUT_FILE
    if $NGINX_BIN -t >> $OUTPUT_FILE 2>&1; then
        notice_to_datadog "mshops.nginx.config_test.ok:1|c|#shell-ec2"
        start_time="$(date -u +%s)"
        systemctl reload nginx
	end_time="$(date -u +%s)"
	elapsed="$(($end_time-$start_time))"
	notice_to_datadog "mshops.nginx.config_restart.elapsed_time:$elapsed|g|#shell-ec2"
        if (systemctl status nginx | tail -1 | grep Reloaded); then
		log_info "Nginx reloaded";
                notice_to_datadog "mshops.nginx.config_reload.ok:1|c|#shell-ec2"
                cp $CONF_HASH_FILE_CURRENT $CONF_HASH_FILE
        else
            log_error "Config reload failed check error file";
            notice_to_datadog "mshops.nginx.config_reload.failed:1|c|#shell-ec2"
	    exit 1
        fi
    else
        log_error "Config test failed check error file";
        notice_to_datadog "mshops.nginx.config_test.failed:1|c|#shell-ec2"
	exit 1
    fi
}

log_info () {
    log "$1" "INFO";
}

log_error () {
    log "$1" "ERROR";
}

log () {
    datestring=$(date +'%Y-%m-%d %H:%M:%S');
    msg=$1;
    level=${2:-'INFO'};

    echo -e "$datestring [$level] $INSTANCE_ID $msg" | tee --append $LOG_FILE;
}

notice_to_datadog(){
    echo -n "$1" > /dev/udp/localhost/8125
}

main
