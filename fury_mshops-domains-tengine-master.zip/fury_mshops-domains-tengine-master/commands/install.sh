#!/bin/bash
NGINX_VERSION=2.3.2
INSTALL_SOURCES=/opt/mshops-domains-tengine

# Install script for building an "NGINX PRODUCTION READY" base docker image.
#

#########
# apt-get update
#########
echo "[ apt-get update] - updating..."
apt-get update

#########
# install aws utils
#########
echo "[ install aws utils] - insatalling..."
apt-get -y install amazon-efs-utils
apt-get -y install nfs-common

#########
# install rclone
#########
curl https://rclone.org/install.sh | bash

#########
# INSTALL DEPENDENCIES
#########

echo "[ NGINX ] - INSTALLING DEPENDENCIES..."
apt-get install --assume-yes --allow-downgrades --allow-remove-essential --allow-change-held-packages build-essential libpcre3 libpcre3-dev zlib1g zlib1g-dev libssl-dev libossp-uuid-dev curl net-tools lsof tcpdump vim

echo "[ NGINX ] - INSTALLING LUA..."
export LUAJIT_LIB=/usr/local/lib
export LUAJIT_INC=/usr/local/include/luajit-2.1/

cd /usr/src
rm -rf luajit2*
curl https://codeload.github.com/openresty/luajit2/tar.gz/v2.1-20201012-2 -o luajit2-2.1-20201012-2.tar.gz
tar xf luajit2-2.1-20201012-2.tar.gz
cd /usr/src/luajit2-2.1-20201012-2 && make
cd /usr/src/luajit2-2.1-20201012-2 && make install

#########
# INSTALL NGNIX BASE AND EXTRA MODULES
#########

echo "[ NGINX ] - DOWNLOADING BASE PACKAGES..."
cd /usr/src
rm -rf nginx* tengine*
curl https://codeload.github.com/alibaba/tengine/tar.gz/${NGINX_VERSION} -o nginx-${NGINX_VERSION}.tar.gz
tar xf nginx-${NGINX_VERSION}.tar.gz && mv tengine-${NGINX_VERSION} nginx-${NGINX_VERSION}

echo "[ NGNIX ] - DOWNLOADING EXTRA MODULES.."
modules=("openresty/echo-nginx-module/v0.62"
"vision5/ngx_devel_kit/v0.3.1"
"openresty/headers-more-nginx-module/v0.33"
"openresty/lua-nginx-module/v0.10.14"
"openresty/set-misc-nginx-module/v0.32"
)
for t in ${modules[@]}; do
  path=$(echo $t | cut -d'/' -f 1)
  name=$(echo $t | cut -d'/' -f 2)
  version=$(echo $t | cut -d'/' -f 3)
  cd /usr/src/nginx-${NGINX_VERSION}/modules && (test -d $name || (curl https://codeload.github.com/$path/$name/tar.gz/$version -o $name.tar.gz && mkdir $name && tar xf $name.tar.gz -C $name --strip-components 1))
done

echo "[ NGINX ] - CONFIGURE, MAKE AND INSTALL "
cd /usr/src/nginx-${NGINX_VERSION} && ./configure --prefix=/usr/local/nginx --with-ld-opt="-lossp-uuid" --with-cc-opt="-I/usr/include/ossp" \
  --add-module=/usr/src/nginx-${NGINX_VERSION}/modules/echo-nginx-module \
  --add-module=/usr/src/nginx-${NGINX_VERSION}/modules/ngx_devel_kit \
  --add-module=/usr/src/nginx-${NGINX_VERSION}/modules/headers-more-nginx-module \
  --add-module=/usr/src/nginx-${NGINX_VERSION}/modules/lua-nginx-module \
  --add-module=/usr/src/nginx-${NGINX_VERSION}/modules/set-misc-nginx-module \
  --add-module=/usr/src/nginx-${NGINX_VERSION}/modules/ngx_http_upstream_dynamic_module \
  --with-http_stub_status_module
cd /usr/src/nginx-${NGINX_VERSION} && make
cd /usr/src/nginx-${NGINX_VERSION} && make install

# Create symlink to avoid error detailed in:
# https://github.com/openresty/lua-nginx-module/issues/8#issuecomment-107794443
ln -sf /usr/local/lib/libluajit-5.1.so.2 /lib/libluajit-5.1.so.2

#########
# Copy and overwrite config, logrotate and nginx.service files
#########
echo "[ copy nginx files] - copying config files..."
# nginx logrotate file
cp  "$INSTALL_SOURCES"/conf/nginx /etc/logrotate.d/
# nginx service file
cp  "$INSTALL_SOURCES"/conf/nginx.service /lib/systemd/system/
# logrotate service file
cp  "$INSTALL_SOURCES"/conf/logrotate.service /lib/systemd/system/

echo "[ NGINX ] - ADDING NEW NGNIX TO PATH..."
test -f /usr/local/sbin/nginx || ln -s /usr/local/nginx/sbin/nginx /usr/local/sbin/nginx
