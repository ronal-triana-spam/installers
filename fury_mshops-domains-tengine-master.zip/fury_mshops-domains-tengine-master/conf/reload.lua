-- Define log tags
tags = '[job:nginx] [module:lua_refresh_config] [log_level:ERROR] '

-- Checking source IP
if string.match(ngx.var.remote_addr, '^172%.17') == nil then
  ngx.exit(ngx.HTTP_FORBIDDEN)
end

-- Get version from BODY
body = ngx.req.get_body_data()

if body == nil then
  ngx.log(ngx.STDERR, tags..'Reload request with no body')
  ngx.status = ngx.HTTP_BAD_REQUEST
  ngx.say('Version must be provided in request body')
  ngx.exit(ngx.HTTP_BAD_REQUEST)
end

version = string.match(body, "[\"'][Vv][Ee][Rr][Ss][Ii][Oo][Nn][\"']%s*:%s*[\"'](.+)[\"']")

if version == nil then
  ngx.log(ngx.STDERR, tags..'Reload request with nil version')
  ngx.status = ngx.HTTP_BAD_REQUEST
  ngx.say('Version must be provided in request body')
  ngx.exit(ngx.HTTP_BAD_REQUEST)
end

ngx.log(ngx.INFO, tags..'Reload request with version:'..version)

-- Sending reload signal to nginx
local status = os.execute("/usr/local/nginx/sbin/nginx -s reload > /tmp/nginx_reload.log")

-- Check reload status code
if status == 0 then
  ngx.exit(ngx.HTTP_OK)
else
  reload_log = io.open('/tmp/nginx_reload.log', "r" )
  reload_log_data = reload_log:read( "*all" )
  reload_log:close()
  ngx.log(ngx.STDERR, tags..'Problem reloading config. exit_code='..status..' error_message='..reload_log_data)
  ngx.status = ngx.HTTP_INTERNAL_SERVER_ERROR
  ngx.say('Problem reloading config')
  ngx.exit(ngx.HTTP_INTERNAL_SERVER_ERROR)
end
