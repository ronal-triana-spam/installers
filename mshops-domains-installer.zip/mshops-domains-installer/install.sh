#!/bin/bash
TENGINE_VERSION=3.1.0

#########
# apt-get update
#########
echo "[ apt-get update] - updating..."
apt-get update

#########
# INSTALL DEPENDENCIES
#########

echo "[ NGINX ] - INSTALLING DEPENDENCIES..."

NEEDRESTART_MODE=a apt-get install --assume-yes --allow-downgrades --allow-remove-essential --allow-change-held-packages build-essential openssl libssl-dev \
libpcre3 libpcre3-dev \
zlib1g-dev \
libxml2 libxml2-dev libxslt-dev \
libgd-dev \
libgeoip1 libgeoip-dev

echo "[ NGINX ] - DOWNLOADING BASE PACKAGES..."
cd /usr/src
rm -rf nginx* tengine*
curl https://codeload.github.com/alibaba/tengine/tar.gz/${TENGINE_VERSION} -o nginx-${TENGINE_VERSION}.tar.gz
tar xf nginx-${TENGINE_VERSION}.tar.gz && mv tengine-${TENGINE_VERSION} nginx-${TENGINE_VERSION}

echo "[ NGNIX ] - DOWNLOADING EXTRA MODULES.."
modules=("openresty/echo-nginx-module/v0.63")
for t in ${modules[@]}; do
  path=$(echo $t | cut -d'/' -f 1)
  name=$(echo $t | cut -d'/' -f 2)
  version=$(echo $t | cut -d'/' -f 3)
  cd /usr/src/nginx-${TENGINE_VERSION}/modules && (test -d $name || (curl https://codeload.github.com/$path/$name/tar.gz/$version -o $name.tar.gz && mkdir $name && tar xf $name.tar.gz -C $name --strip-components 1))
done

echo "[ NGINX ] - CONFIGURE, MAKE AND INSTALL "
cd /usr/src/nginx-${TENGINE_VERSION} && ./configure --prefix=/usr/local/nginx \
  --add-module=/usr/src/nginx-${TENGINE_VERSION}/modules/echo-nginx-module \
  --add-module=/usr/src/nginx-${TENGINE_VERSION}/modules/ngx_http_upstream_dynamic_module \
  --with-http_stub_status_module \
  --with-stream=dynamic

cd /usr/src/nginx-${TENGINE_VERSION} && make
cd /usr/src/nginx-${TENGINE_VERSION} && make install

#mkdir /usr/local/nginx/conf/mappings
cp -R /home/ubuntu/mshops-domains-installer/mappings /usr/local/nginx/conf/
cp /home/ubuntu/mshops-domains-installer/conf/nginx.conf /usr/local/nginx/conf/
cp /home/ubuntu/mshops-domains-installer/conf/server_shop_proxy_pass.conf /usr/local/nginx/conf/

#########
# Copy and overwrite config, logrotate and nginx.service files
#########
echo "[ copy nginx files] - copying config files..."
# nginx logrotate file
cp  /home/ubuntu/mshops-domains-installer/conf/nginx /etc/logrotate.d/
# nginx service file
cp  /home/ubuntu/mshops-domains-installer/conf/nginx.service /lib/systemd/system/
# logrotate service file
cp  /home/ubuntu/mshops-domains-installer/conf/logrotate.service /lib/systemd/system/

echo "[ NGINX ] - ADDING NEW NGNIX TO PATH..."
test -f /usr/local/sbin/nginx || ln -s /usr/local/nginx/sbin/nginx /usr/local/sbin/nginx

#########
# enable boot start nginx
#########
echo "[ enable nginx as service ] - enabling nginx.service..."
systemctl enable nginx.service

#########
# start nginx
#########
echo "[ start nginx ] - starting nginx..."
systemctl start nginx
